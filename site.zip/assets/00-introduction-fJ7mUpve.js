const e=`# Getting started\r
\r
!!! info "The Global Language Gap"\r
    The world speaks more than 7,000 languages, yet most large language models are trained on data that is almost entirely English. In many cases, more than 90% of the training corpus is English. This imbalance creates a massive gap that leaves billions of people at a disadvantage. \r
\r
    Models built on English heavy datasets struggle to understand or generate text in languages with limited digital presence. This affects accuracy, reliability, cultural fit, and safety. \r
\r
---\r
\r
## The multilingual AI challenge\r
\r
If you are building LLM powered applications for global audiences, you face a fundamental reality: the models you rely on are overwhelmingly optimized for English. GPT-3's training data is approximately 92.65% English, and Llama 2's data is nearly 90% English. Researchers call this imbalance the resourcedness gap, and it systematically disadvantages languages with low online representation.\r
\r
!!! warning "The Real-World Impact"\r
    This gap appears in three critical ways:\r
    \r
    - **📉 Lower accuracy**. Non-English tasks often perform dramatically worse.\r
    - **🌍 Cultural Misalignment**. AI systems miss local context, tone, conventions, and norms. \r
    - **⚠️ Safety Risks**: Filters that block harmful content in English fail in other languages, sometimes by a factor of three or more. \r
\r
For developers building chatbots, customer support systems, content moderation tools, or coding assistants, this creates difficult decisions. Should you translate everything into English? Prompt in the user's language? Fine-tune your own model? **The wrong choice can waste resources, create poor user experiences, or cause real harm.**\r
\r
---\r
\r
## Why you need a structured framework\r
\r
Building multilingual applications is inherently challenging and can involve trial and error in development, potentially wasting time and introducing risks. Teams that are new to multilingual development may try different methods without fully understanding the consequences. The common pitfalls may include  \r
\r
\r
!!! success "The Vibhasha Solution"\r
    That is why this playbook exists. Vibhasha provides a research grounded decision making framework that helps you move from guesswork to clarity. It does not prescribe a single “best” approach. Instead, it helps you understand: \r
    \r
    - ✅ When each strategy works best\r
    - ✅ What resources each strategy requires\r
    - ✅ What tradeoffs you accept with each choice \r
    \r
\r
### Common development pitfalls\r
\r
!!! warning "Without a framework, multilingual development often leads to predictable problems: "\r
    \r
    **❌ Inconsistent results**  \r
    A technique that works for French may fail completely for Swahili or Tamil. \r
    \r
    **💸 Hidden costs**  \r
    Translation pipelines that look simple at first can multiply API calls and latency. \r
    \r
    **🎭 Cultural blindness**  \r
    Systems may “work” technically but produce awkward, confusing, or offensive outputs. \r
    \r
    **🔓 Safety gaps**  \r
    A model may refuse harmful requests in English but comply when asked in another language. \r
    \r
    **🔄 Wasted iterations**  \r
    Teams test options without clear success criteria or guidance on when to pivot. \r
\r
Vibhasha provides a principled decision-making framework grounded in empirical research and real-world deployments. Rather than offering one-size-fits-all solutions, this playbook helps you understand:  \r
\r
---\r
\r
## Three implementation strategies\r
\r
Based on research conducted over 20 years at Microsoft Research India and the multilingual NLP research community, and production deployments, multilingual systems typically rely on one of three core strategies. Each offers a different way to bridge the gap between English optimized models and global users. \r
\r
!!! info "Strategy 1: 🌐 Translation-Based Approaches"\r
    \r
    **Leverage translation as a bridge to English-centric model capabilities**\r
    \r
    This strategy translates user inputs to English, processes them with a strong English model, then translates outputs back to the user’s language. \r
\r
    Modern versions use selective translation, where only certain parts of a prompt are translated. In many cases, selective translation outperforms full translation or direct prompting for under-resourced languages. \r
    \r
    **Best for:** Quick prototyping and languages supported by high quality machine translation. \r
\r
    **How selective translation works:**\r
\r
    - **Extractive tasks** (Q&A, NER): Keep the context in the source language and translate only the instructions.\r
    - **Generative tasks** (summarization): Generate the response in English, then translate it back.\r
    - **Direct inference**: In some cases, prompting directly in the source language yields better results.\r
\r
    **Tradeoffs:**\r
\r
    - Potential loss of cultural nuance\r
    - Compounding translation errors\r
    - Increased latency and cost from extra translation steps \r
    \r
    [→ Learn more](/playbook/02-translation-overview)\r
\r
!!! info "Strategy 2: 💬 Off-the-Shelf Prompting"\r
    \r
    **Use pretrained multilingual models through strategic prompt engineering**\r
    \r
    This strategy uses multilingual models directly, relying on careful prompt engineering. Modern LLMs such as GPT-4, Claude, and open models like Llama offer built in multilingual capabilities. \r
\r
    This approach uses techniques such as few shot examples, cultural framing, persona prompts, and retrieval augmented generation (RAG). \r
\r
    **Advantages:**\r
\r
    - Fastest to deploy with no training infrastructure\r
    - Quick iteration across languages and prompt styles\r
    - Strong potential for cultural adaptation through prompt design\r
\r
    **Limitations:**\r
\r
    - Performance declines significantly for under-resourced languages\r
    - Fragile prompts where small changes lead to inconsistent outputs\r
    - No persistent learning because each interaction starts fresh \r
    \r
    **Best for:** Rapid prototyping and medium to high resource languages.\r
    \r
    [→ Learn more](/playbook/02-translation-overview)\r
\r
!!! info "Strategy 3: ⚙️ Fine-Tuning Specialized Models"\r
    \r
    **Adapt lightweight models on domain-specific, culturally relevant data**\r
    \r
    This strategy adapts lightweight open-source models using domain specific, culturally relevant, or language specific data. \r
\r
    Fine-tuning enables deep customization. The model can learn domain terminology, cultural norms, local idioms, and preferred communication styles. Techniques like LoRA make fine-tuning cost efficient by updating only a small percentage of the model’s parameters. \r
\r
    **Advantages:**\r
\r
    - Maximum control and cultural fidelity\r
    - Ability to run in private or air-gapped environments\r
    - Long-term cost savings after the initial training investment\r
\r
    **Tradeoffs:**\r
\r
    - Requires high-quality training data\r
    - Requires infrastructure for training and evaluation\r
    - Smaller models may struggle with complex reasoning tasks \r
    \r
    **Best for:** Domain specific applications, under-resourced languages, and environments with strict privacy or security needs.\r
    \r
    [→ Learn more](/playbook/04-fine-tuning-overview)\r
\r
---\r
<!-- \r
\r
\r
[→ Master Fine-Tuning Strategies](/playbook/04-fine-tuning-overview){ .md-button }\r
--- -->\r
\r
\r
## Cross-cutting concerns: evaluation and safety\r
\r
!!! warning "Critical: These Apply to ALL Strategies"\r
    No matter which strategy you choose, evaluation and safety checks are essential. \r
\r
### 📊 Robust multilingual evaluation\r
\r
English centric benchmarks are not reliable indicators of multilingual performance, and safety systems trained mostly on English create significant blind spots. Harmful content rates can be three times higher in under-resourced languages, and multilingual jailbreaking attacks succeed far more often than monolingual ones. \r
\r
\r
**What You Must Do:**\r
\r
- ✅ Test safety across all target languages (especially under-resourced)\r
- ✅ Use multilingual adversarial benchmarks\r
- ✅ Implement cross-lingual safety filters\r
- ✅ Monitor for cultural context-specific harms\r
\r
[→ Comprehensive Safety Assessments](/playbook/05-safety-overview){ .md-button .md-button--primary }\r
\r
---\r
\r
### Addressing data scarcity: synthetic data generation\r
\r
!!! info "The Under-Resourced Language Problem"\r
    Across all strategies, a recurring challenge is the **lack of high-quality data** for under-resourced languages. Synthetic data has become a practical solution. \r
\r
A typical approach includes:\r
\r
- Translating established English datasets\r
- Using LLMs to generate multilingual examples\r
- Validating data with automated checks and human reviewers\r
- Adapting examples to reflect local culture and values \r
\r
Synthetic data does not replace real data, but it can meaningfully supplement it when created purposefully. \r
\r
<!-- **What Synthetic Data Enables:**\r
\r
| Use Case | Description |\r
|----------|-------------|\r
| 🧪 **Evaluation Datasets** | Generate test cases for languages lacking benchmarks |\r
| 💡 **Few-Shot Examples** | Create in-context examples for prompt engineering |\r
| 📚 **Training Data** | Build instruction-following datasets for fine-tuning |\r
| 🌍 **Cultural Grounding** | Adapt examples to reflect local context and norms |\r
\r
**Systematic Framework:**\r
\r
1. **Generation Strategies** - Translate English datasets, use LLMs to generate multilingual content\r
2. **Quality Checks** - Automatic metrics + human-in-the-loop validation\r
3. **Cultural Adaptation** - Ensure examples reflect local values and context\r
4. **Downstream Evaluation** - Verify synthetic data actually improves model performance\r
\r
!!! tip "Practical Application"\r
    Translate and culturally adapt English instruction-following datasets (e.g., Alpaca, Dolly) to create training data for underrepresented languages. -->\r
\r
[→ Synthetic Data Generation Framework](/playbook/06-synthetic-data-overview){ .md-button }\r
\r
---\r
\r
## How to navigate this playbook\r
\r
!!! info "Choose Your Path"\r
    This playbook is designed to be read in whichever order fits your needs. \r
\r
### 🚀 If you are just getting started:\r
\r
<!-- Explore the [Interactive Flowchart](/playbook/flowchart) -->\r
Use the interactive flowchart(/playbook/flowchart) for a quick overview of recommended strategies. \r
\r
### ⚡ If you need quick results:\r
\r
<!-- - [Translation](/playbook/02-translation-overview) for leveraging existing MT services\r
- [Off-the-Shelf Prompting](/playbook/02-translation-overview) for rapid prototyping -->\r
\r
[Translation](/playbook/02-translation-overview) and [Off-the-Shelf Prompting](/playbook/02-translation-overview) offer the fastest path to a working prototype.\r
\r
\r
### 🏭 If you are building for production:\r
\r
Start with [Evaluation](/playbook/01-evaluation-overview) and [Safety](/playbook/05-safety-overview), then choose an approach that balances your goals with available resources.\r
\r
### 🎯 Have specialized needs?\r
\r
\r
[Fine-Tuning](/playbook/04-fine-tuning-overview) and [Synthetic Data](/playbook/06-synthetic-data-overview) provide the strongest performance for culturally specific or domain heavy applications.\r
\r
\r
Each chapter stands alone but connects to others where concepts overlap. The guidance combines research insights and lessons from real world deployments, supported by decision matrices and concrete, step-by-step instructions. `;export{e as default};
