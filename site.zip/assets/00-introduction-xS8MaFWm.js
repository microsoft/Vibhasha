const e=`# Introduction\r
\r
!!! quote "The Global Language Gap"\r
    While the world speaks **7,000+ languages**, modern LLMs are trained on corpora that are **~90% English**. This fundamental imbalance creates systematic disadvantages for billions of people.\r
\r
---\r
\r
## The Multilingual AI Challenge\r
\r
When building LLM-powered applications for global audiences, developers face a fundamental disconnect: while the world speaks over 7,000 languages, modern LLMs are overwhelmingly optimized for English. Approximately **92.65% of GPT-3's training corpus** and **89.70% of Llama 2's pretraining data** is English[^1], creating what researchers call a "resourcedness gap" that systematically disadvantages speakers of most languages—especially those with limited digital presence.\r
\r
!!! danger "The Real-World Impact"\r
    This imbalance isn't just a technical inconvenience. It manifests in three critical ways:\r
    \r
    - **📉 Degraded Performance**: Non-English tasks show dramatically lower accuracy\r
    - **🌍 Cultural Misalignment**: AI systems fail to capture local context and norms\r
    - **⚠️ Safety Vulnerabilities**: Harmful content filters that work in English fail catastrophically in other languages—sometimes by a **factor of 3× or more**[^2]\r
\r
For developers building chatbots, customer support systems, content moderation tools, or coding assistants, this creates a complex web of decisions: Should you translate everything to English? Use models directly in the target language? Fine-tune your own model? **The wrong choice wastes resources, delivers poor user experiences, or worse, causes harm.**\r
\r
---\r
\r
## Why You Need a Structured Framework\r
\r
The typical development approach—trying various methods through trial and error—is both inefficient and risky. Teams often experiment with translating inputs, changing prompt languages, or switching models without understanding the underlying trade-offs. \r
\r
### Common Development Pitfalls\r
\r
!!! failure "What Goes Wrong Without a Framework"\r
    \r
    **❌ Inconsistent results**  \r
    What works for French may fail completely for Swahili or Tamil\r
    \r
    **💸 Hidden costs**  \r
    Translation pipelines that seem simple multiply API costs and latency\r
    \r
    **🎭 Cultural blindness**  \r
    Systems that technically "work" but produce outputs that are awkward, offensive, or miss local context entirely\r
    \r
    **🔓 Safety gaps**  \r
    Models that refuse harmful requests in English but comply in other languages\r
    \r
    **🔄 Wasted iterations**  \r
    Testing approaches without clear success criteria or understanding when to pivot\r
\r
!!! success "The Vibhasha Solution"\r
    **Vibhasha** provides a **principled decision-making framework** grounded in empirical research and real-world deployments. Rather than offering one-size-fits-all solutions, this playbook helps you understand:\r
    \r
    - ✅ When each approach excels\r
    - ✅ What resources it requires\r
    - ✅ What trade-offs you're accepting\r
    \r
    **Goal**: Move from guesswork to informed strategy, ensuring your multilingual LLM system is effective, culturally appropriate, and aligned with your resource constraints.\r
\r
---\r
\r
## Three Implementation Strategies\r
\r
Based on empirical research and production deployments, multilingual LLM applications typically adopt one of three core implementation strategies. Each represents a distinct approach to bridging the gap between English-optimized models and global users.\r
\r
!!! note "Strategy 1: 🌐 Translation-Based Approaches"\r
    \r
    **Leverage translation as a bridge to English-centric model capabilities**\r
    \r
    Translate inputs to English, process with powerful models, translate outputs back. Modern approaches use **selective translation** for optimal results.\r
    \r
    **Best for:** Quick prototyping, well-supported languages\r
    \r
    [→ Learn more](/playbook/02-translation-overview)\r
\r
!!! note "Strategy 2: 💬 Off-the-Shelf Prompting"\r
    \r
    **Use pretrained multilingual models through strategic prompt engineering**\r
    \r
    Leverage built-in multilingual capabilities through careful prompt design, few-shot examples, and cultural framing.\r
    \r
    **Best for:** Rapid iteration, mid-to-high resource languages\r
    \r
    [→ Learn more](/playbook/02-translation-overview)\r
\r
!!! note "Strategy 3: ⚙️ Fine-Tuning Specialized Models"\r
    \r
    **Adapt lightweight models on domain-specific, culturally relevant data**\r
    \r
    Customize open-source LLMs with your own data for maximum control and cultural fidelity.\r
    \r
    **Best for:** Domain-specific apps, low-resource languages\r
    \r
    [→ Learn more](/playbook/04-fine-tuning-overview)\r
\r
---\r
\r
### 1. Translation-Based Approaches\r
\r
!!! tip "Core Concept"\r
    Leverage translation as a bridge to English-centric model capabilities.\r
\r
The most straightforward approach involves translating non-English input to English, processing it with a powerful English-optimized LLM, and translating the output back. However, modern translation strategies have evolved far beyond this simple pipeline. \r
\r
!!! success "Key Research Finding"\r
    **Selective translation**—where you strategically choose which parts of your prompt to translate—consistently outperforms both full translation and direct prompting, often by **100-200%** for low-resource languages[^3].\r
\r
**Strategic Nuances:**\r
\r
- **For extractive tasks** (Q&A, NER): Keep context in source language, translate only instructions\r
- **For generative tasks** (summarization): Generate in English, then translate back\r
- **Direct inference**: Sometimes prompting in source language outperforms any translation\r
\r
| Scenario | Recommended Approach | Why |\r
|----------|---------------------|-----|\r
| Low-resource language (Bambara, Quechua, Lingala) | Full or selective translation | LLM's native support is too weak |\r
| Extractive task (Q&A) | Keep context in source, translate instruction | Prevents information loss |\r
| Generative task (summarization) | Generate in English, translate back | Leverages strongest capabilities |\r
| Mid-resource language | Direct inference first | Built-in multilingual capability often sufficient |\r
\r
??? example "When to Use Translation"\r
    ✅ Quick prototyping  \r
    ✅ Well-supported languages with quality MT services  \r
    ✅ Specific low-resource languages where empirical evidence shows translation wins  \r
    \r
    ⚠️ **Trade-offs**: Cultural nuance loss, compounding errors, increased latency/cost\r
\r
[→ Deep dive into Translation Strategies](/playbook/02-translation-overview){ .md-button }\r
\r
### 2. Off-the-Shelf Prompting\r
\r
!!! tip "Core Concept"\r
    Use pretrained multilingual models directly through strategic prompt engineering.\r
\r
Modern LLMs like GPT-4, Claude, and open models like Llama have multilingual capabilities built-in from pretraining on diverse corpora. This strategy leverages those capabilities through careful prompt design—using few-shot examples, cultural framing, persona-based prompts, or retrieval-augmented generation (RAG) to elicit appropriate multilingual behavior without any model training.\r
\r
**Key Advantages:**\r
\r
- ⚡ **Fastest to deploy** - No training infrastructure needed\r
- 🔄 **Rapid iteration** - Test different prompt phrasings quickly\r
- 🎭 **Cultural adaptation** - Embed cultural context through prompts alone\r
- 🌐 **Works well** for mid-to-high resource languages\r
\r
**Key Limitations:**\r
\r
- 📉 **Performance degrades sharply** for low-resource languages\r
- 🎲 **Inherently fragile** - Small wording changes = dramatic differences\r
- 🎯 **Hard to control** - Difficult to maintain consistent tone/style\r
- 🔒 **No persistent learning** - Each interaction starts fresh\r
\r
??? example "When to Use Off-the-Shelf Prompting"\r
    ✅ Rapid prototyping or proof-of-concept  \r
    ✅ Mid-to-high resource languages (Spanish, French, Hindi, etc.)  \r
    ✅ Can invest in prompt iteration but lack training infrastructure  \r
    ✅ Cultural framing can be embedded in prompts  \r
    \r
    ⚠️ **Trade-offs**: Inconsistent across languages, limited for low-resource scenarios\r
\r
[→ Explore Prompting Techniques](/playbook/02-translation-overview){ .md-button }\r
\r
### 3. Fine-Tuning Specialized Models\r
\r
!!! tip "Core Concept"\r
    Adapt lightweight open-source models on domain-specific, culturally relevant data.\r
\r
Fine-tuning involves taking a smaller, open-source LLM (e.g., Mistral, Phi, Gemma) and retraining it on curated multilingual data specific to your domain and culture. This enables deep customization—the model learns domain terminology, local idioms, cultural norms, and appropriate responses for your specific context. \r
\r
!!! info "Modern Efficiency"\r
    Parameter-efficient fine-tuning techniques like **LoRA** make this feasible even with limited compute by updating only a small fraction of model weights.\r
\r
**Maximum Control & Cultural Fidelity:**\r
\r
- 🎯 **Deep customization** - Captures domain-specific nuances\r
- 🏛️ **Cultural alignment** - Learns from local language context\r
- 🔐 **Privacy & control** - Deploy in air-gapped environments\r
- 💰 **Long-term cost savings** - Lower API costs after initial investment\r
\r
**Upfront Investment Required:**\r
\r
- 📊 **Quality training data** (or synthetic data generation)\r
- 💻 **Training infrastructure** and expertise\r
- 🧪 **Evaluation frameworks** across languages\r
- ⚠️ **Smaller models** may struggle with complex reasoning\r
\r
| Use Case | Why Fine-Tuning Wins |\r
|----------|---------------------|\r
| Domain-specific (legal, medical) | Learns specialized terminology & context |\r
| Low-resource languages | General models underperform significantly |\r
| Privacy-sensitive deployments | Full control over data & infrastructure |\r
| Cultural value alignment | Trains on culturally appropriate responses |\r
| Local dialects | Captures linguistic variations |\r
\r
??? example "When to Use Fine-Tuning"\r
    ✅ Domain-specific applications (customer support, legal, medical)  \r
    ✅ Low-resource languages underserved by general models  \r
    ✅ Privacy-sensitive deployments  \r
    ✅ Need precise cultural alignment or value representation  \r
    \r
    ⚠️ **Trade-offs**: Data collection, infrastructure needs, expertise required\r
\r
[→ Master Fine-Tuning Strategies](/playbook/04-fine-tuning-overview){ .md-button }\r
\r
---\r
\r
## Cross-Cutting Concerns: Evaluation and Safety\r
\r
!!! warning "Critical: These Apply to ALL Strategies"\r
    Regardless of which implementation strategy you choose, robust evaluation and safety assessments are **non-negotiable** for production multilingual systems.\r
\r
### 📊 Robust Multilingual Evaluation\r
\r
Standard English-centric benchmarks fail to capture the true performance of multilingual systems. Evaluation becomes particularly challenging when:\r
\r
<div class="grid" markdown>\r
\r
!!! failure "Evaluation Challenges"\r
    \r
    **📚 Data Contamination**  \r
    Benchmark datasets may be in the model's training data\r
    \r
    **📊 Inadequate Metrics**  \r
    BLEU/ROUGE fail to capture subjective quality\r
    \r
    **👥 Human Evaluation**  \r
    Requires native speakers for each language\r
    \r
    **📉 Performance Variance**  \r
    Dramatic differences between high/low-resource languages\r
\r
!!! success "Evaluation Solutions"\r
    \r
    **⚖️ Pairwise Comparison**  \r
    Elo ratings for relative model ranking\r
    \r
    **✅ Direct Assessment**  \r
    Linguistic acceptability, task quality, hallucination detection\r
    \r
    **🤖 LLM-as-a-Judge**  \r
    Scalable evaluation (when validated against humans)\r
    \r
    **🎯 Custom Metrics**  \r
    Domain-specific evaluation frameworks\r
\r
</div>\r
\r
[→ Complete Evaluation Framework](/playbook/01-evaluation-overview){ .md-button .md-button--primary }\r
\r
---\r
\r
### 🛡️ Multilingual Safety Assessments\r
\r
!!! danger "The 3× Safety Risk"\r
    Safety mechanisms trained primarily on English data create **dangerous blind spots** in other languages. Harmful content rates can be **3× higher** in low-resource languages, and multilingual jailbreaking attacks achieve:\r
    \r
    - **80.92% success rate** on ChatGPT\r
    - **40.71% success rate** on GPT-4[^2]\r
\r
**Safety Failure Modes:**\r
\r
| Failure Type | Description | Impact |\r
|--------------|-------------|--------|\r
| 🔓 **Unintentional Bypass** | Users in low-resource languages inadvertently receive policy violations | Widespread harm to vulnerable populations |\r
| 🎯 **Intentional Attacks** | Cross-lingual jailbreaking exploits safety gaps | Malicious use, reputational damage |\r
| 💭 **Hallucination Toxicity** | Factual errors in low-resource languages introduce toxic content | Misinformation + harm combined |\r
| 🌐 **Inconsistent Policies** | Different safety responses across languages | Unfair user experiences |\r
\r
**What You Must Do:**\r
\r
- ✅ Test safety across all target languages (especially low-resource)\r
- ✅ Use multilingual adversarial benchmarks\r
- ✅ Implement cross-lingual safety filters\r
- ✅ Monitor for cultural context-specific harms\r
\r
[→ Comprehensive Safety Assessments](/playbook/05-safety-overview){ .md-button .md-button--primary }\r
\r
---\r
\r
## Addressing Data Scarcity: Synthetic Data Generation\r
\r
!!! question "The Low-Resource Language Problem"\r
    A recurring challenge across all strategies: **scarcity of high-quality data** in low-resource languages for evaluation, prompting, and training.\r
\r
Whether you need evaluation datasets, few-shot examples for prompting, or training data for fine-tuning, creating **synthetic data** has emerged as a practical solution.\r
\r
**What Synthetic Data Enables:**\r
\r
| Use Case | Description |\r
|----------|-------------|\r
| 🧪 **Evaluation Datasets** | Generate test cases for languages lacking benchmarks |\r
| 💡 **Few-Shot Examples** | Create in-context examples for prompt engineering |\r
| 📚 **Training Data** | Build instruction-following datasets for fine-tuning |\r
| 🌍 **Cultural Grounding** | Adapt examples to reflect local context and norms |\r
\r
**Systematic Framework:**\r
\r
1. **Generation Strategies** - Translate English datasets, use LLMs to generate multilingual content\r
2. **Quality Checks** - Automatic metrics + human-in-the-loop validation\r
3. **Cultural Adaptation** - Ensure examples reflect local values and context\r
4. **Downstream Evaluation** - Verify synthetic data actually improves model performance\r
\r
!!! tip "Practical Application"\r
    Translate and culturally adapt English instruction-following datasets (e.g., Alpaca, Dolly) to create training data for underrepresented languages.\r
\r
[→ Synthetic Data Generation Framework](/playbook/06-synthetic-data-overview){ .md-button }\r
\r
---\r
\r
## How to Navigate This Playbook\r
\r
!!! info "Choose Your Path"\r
    This playbook is designed for different reading paths depending on your immediate needs.\r
\r
### 🚀 Just Starting Out?\r
\r
Explore the [Interactive Flowchart](/playbook/flowchart)\r
\r
Perfect for understanding the landscape.\r
\r
### ⚡ Need Quick Results?\r
\r
- [Translation](/playbook/02-translation-overview) for leveraging existing MT services\r
- [Off-the-Shelf Prompting](/playbook/02-translation-overview) for rapid prototyping\r
\r
Get a working prototype fast.\r
\r
### 🏭 Building for Production?\r
\r
1. Read [Evaluation](/playbook/01-evaluation-overview) first\r
2. Then [Safety](/playbook/05-safety-overview)\r
3. Choose your implementation strategy\r
\r
Understand success criteria & risks upfront.\r
\r
### 🎯 Have Specialized Needs?\r
\r
- [Fine-Tuning](/playbook/04-fine-tuning-overview) for maximum customization\r
- [Synthetic Data](/playbook/06-synthetic-data-overview) for data scarcity\r
\r
Deep dive into advanced techniques.\r
\r
### Reading Strategy\r
\r
!!! tip "How Chapters Are Structured"\r
    \r
    **📖 Independent but Interconnected**  \r
    Each chapter can be read standalone with cross-references where concepts connect\r
    \r
    **🔬 Research-Grounded**  \r
    Concrete examples and empirical evidence from academic research and industry deployments\r
    \r
    **📊 Decision Matrices**  \r
    Clear frameworks mapping your context to recommended strategies\r
    \r
    **⚙️ Practical Implementation**  \r
    Step-by-step guidance, not just theory\r
\r
!!! quote "Our Philosophy"\r
    We don't prescribe a single "best" approach. Instead, we equip you with the knowledge to make **informed decisions** for your specific multilingual context.\r
\r
---\r
\r
**Ready to dive in?** Choose your path above, or start with the [Interactive Flowchart](/playbook/flowchart) for personalized guidance.\r
\r
\r
---\r
\r
[^1]: Mondshine, I., Paz-Argaman, T., & Tsarfaty, R. (2025). Beyond english: The impact of prompt translation strategies across languages and tasks in multilingual llms. arXiv preprint arXiv:2502.09331.\r
\r
[^2]: Kazemi, S., Gerhardt, G., Katz, J., Kuria, C. I., Pan, E., & Prabhakar, U. (2024). Cultural fidelity in large-language models: an evaluation of online language resources as a driver of model performance in value representation. arXiv preprint arXiv:2410.10489.\r
\r
[^3]: Empirical findings from translation strategy research showing selective pre-translation outperforms full translation and direct inference across multiple tasks and languages.\r
`;export{e as default};
