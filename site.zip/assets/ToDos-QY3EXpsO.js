const e=`???+ note "Experimental ToDos"\r
    - [ ] present a dashboard of different tokenizers and their fertility scores\r
        - [ ] fertility scores for different languages\r
        - [ ] fertility scores for different domains - medical, legal, general, etc.\r
        \r
    - [ ] evaluations of different multilingual LLMs on different tasks in lm-eval harness across different language and language families — extend MEGA, MEGAVERSE\r
\r
    - [ ] interactive dashboard for llm-as-judge\r
        - [ ] are there multilingual datasets which have human evaluations?\r
        - [ ] if so, a interactive dashboard to compare llm-as-judge with human evaluations\r
\r
    - [ ] some scripts make sample LLM calls - for demo I have used free endpoints in OpenRouter - we can add azure endpoints for different models.\r
\r
\r
    - [ ] LabelStudio demo for annotations - for human evaluations - they lready have a "Deply to Azure" option on their github. can we build a image which would contain some of the example tasks and let users play around?\r
    \r
\r
???+ note "Improvements To-Do"\r
    - [ ] refer to the code snippets in src and interactive folders in the Vibhasha playbook chapters\r
    - [ ] update interactive flowchat\r
    - [ ] file organization - remove unnecessary nesting of  ~/MultilingualLLM_Playbook/MultilingualPlaybook \r
    - [ ] use uv for package mangement and installation\r
    - [ ] pip install and run elements of src\r
\r
\r
`;export{e as default};
