const a=`##  Safety\r
The State of Multilingual LLM Safety Research:  From Measuring the Language Gap to Mitigating It - https://arxiv.org/pdf/2505.24119\r
Benchmarking LLM Guardrails in Handling Multilingual Toxicity - https://arxiv.org/pdf/2410.22153\r
The Multilingual Divide and Its Impact on  Global AI Safety - https://arxiv.org/pdf/2505.21344\r
All Languages Matter: On the Multilingual Safety of LLMs - https://aclanthology.org/2024.findings-acl.349.pdf\r
Ethical and social risks of harm from Language Models - https://arxiv.org/pdf/2112.04359\r
Multilingual Jailbreak Challenges in Large Language Models - https://openreview.net/pdf?id=vESNKdEMGp\r
AI Alignment: A Comprehensive Survey - https://arxiv.org/pdf/2310.19852\r
Red Teaming Language Models to Reduce Harms:  Methods, Scaling Behaviors, and Lessons Learned - Anthropic - https://arxiv.org/pdf/2209.07858\r
\r
Code-SwitchingRed-Teaming: LLMEvaluationforSafetyandMultilingualUnderstanding - https://aclanthology.org/2025.acl-long.657.pdf\r
LinguaSafe: A Comprehensive Multilingual Safety Benchmark for Large  Language Models - https://arxiv.org/pdf/2508.12733\r
The Multilingual Alignment Prism: Aligning Global and Local Preferences to Reduce Harm - https://arxiv.org/pdf/2406.18682\r
\r
LANGUAGE MODEL ALIGNMENT IN MULTILINGUAL TROLLEY PROBLEMS - https://openreview.net/pdf?id=VEqPDZIDAh\r
\r
SafetyPrompts: a Systematic Review of Open Datasets for Evaluating and Improving Large Language Model Safety - https://arxiv.org/pdf/2404.05399v2\r
\r
Multilingual Jailbreak Challenges in Large Language Models - Multilingual Jailbreak Challenges in Large Language Models\r
SALAD-Bench: A Hierarchical and Comprehensive Safety Benchmark for Large Language Models - https://aclanthology.org/2024.findings-acl.235.pdf\r
\r
\r
## Synthetic Data\r
\r
\r
\r
`;export{a as default};
